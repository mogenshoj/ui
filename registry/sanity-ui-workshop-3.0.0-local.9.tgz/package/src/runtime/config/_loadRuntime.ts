import {TransformOptions} from 'esbuild'

import {WorkshopRuntimeOptions} from '../types'
import {_findRuntimeFile} from './_findRuntimeFile'

/** @internal */
export async function _loadRuntimeConfig(options: {
  packagePath: string
}): Promise<WorkshopRuntimeOptions | undefined> {
  const {packagePath} = options

  const configPath = _findRuntimeFile({packagePath})

  if (!configPath) {
    return undefined
  }

  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const {register} = require('esbuild-register/dist/node')

  const esbuildOptions: TransformOptions = {
    jsx: 'automatic',
    jsxFactory: 'createElement',
    jsxFragment: 'Fragment',
    jsxImportSource: 'react',
    logLevel: 'silent',
  }

  const {unregister} = globalThis.__DEV__ ? {unregister: () => undefined} : register(esbuildOptions)

  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const config = require(configPath)

  // Unregister the require hook if you don't need it anymore
  unregister()

  return config?.default ?? config
}
