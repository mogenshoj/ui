import path from 'path'
import {preview as vitePreview} from 'vite'

import {_loadRuntimeConfig} from './config/_loadRuntime'
import {createViteConfig} from './viteConfig'

/** @alpha */
export async function preview(options: {cwd: string; port?: number}): Promise<void> {
  const {cwd, port = 1337} = options

  const runtimeConfig = await _loadRuntimeConfig({packagePath: cwd})
  const runtimeDir = path.resolve(cwd, '.workshop')

  const outDir = runtimeConfig?.build?.outDir ?? path.resolve(cwd, '.workshop/dist')

  const baseViteConfig = createViteConfig({
    cwd,
    mode: 'production',
    outDir,
    runtimeDir,
  })

  let viteConfig = runtimeConfig?.vite?.(baseViteConfig) ?? baseViteConfig

  // check if viteConfig is a promise
  if (typeof viteConfig === 'object' && 'then' in viteConfig) {
    viteConfig = await viteConfig
  }

  const previewServer = await vitePreview({
    ...viteConfig,
    preview: {port},
  })

  previewServer.printUrls()
  previewServer.bindCLIShortcuts({print: true})
}
