import {usePrefersDark} from '@sanity/ui'
import {ThemeColorSchemeKey} from '@sanity/ui/theme'
import {StrictMode, useMemo, useState} from 'react'
import {createRoot} from 'react-dom/client'

import {WorkshopConfig} from './config'
import {createLocationStore} from './location'
import {Workshop} from './Workshop'

/** @beta */
export function mount(options: {config: WorkshopConfig; element: HTMLElement | null}): void {
  const {config, element} = options

  if (!element) throw new Error('missing element')

  const root = createRoot(element)

  root.render(
    <StrictMode>
      <Root config={config} />
    </StrictMode>,
  )
}

function Root(props: {config: WorkshopConfig}) {
  const {config} = props
  const prefersDark = usePrefersDark()
  const locationStore = useMemo(() => createLocationStore(), [])

  const [initialScheme] = useState((): ThemeColorSchemeKey => (prefersDark ? 'dark' : 'light'))

  return <Workshop config={config} locationStore={locationStore} initialScheme={initialScheme} />
}
