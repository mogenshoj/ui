import {Card, Heading, Spinner, Stack, Text} from '@sanity/ui'
import {memo, useState} from 'react'

import {VIEWPORT_OPTIONS} from './constants'
import {buildFrameUrl} from './helpers'
import {useWorkshop} from './useWorkshop'

/** @internal */
export const WorkshopCanvas = memo(function WorkshopCanvas(props: {
  frameRef: React.Ref<HTMLIFrameElement>
  hidden: boolean
}): React.ReactNode {
  const {frameRef, hidden} = props
  const {frameReady, frameUrl, path, payload, title, viewport, zoom} = useWorkshop()
  const viewportOption = VIEWPORT_OPTIONS.find((o) => o.name === viewport) ?? VIEWPORT_OPTIONS[0]
  const viewportW = viewportOption.rect.width
  const viewportH = viewportOption.rect.height

  const [initialFrameUrl] = useState(() =>
    buildFrameUrl({baseUrl: frameUrl, path, payload, viewport, zoom}),
  )

  return (
    <Card
      alignItems="center"
      flexDirection="column"
      display={hidden ? 'none' : 'flex'}
      flex={1}
      justifyContent="center"
      overflow="hidden"
      tone="transparent"
    >
      {path === '/' && (
        <Stack padding={4} gap={4} marginX="auto" maxWidth={1} sizing="border" width="fill">
          <Heading align="center" size={1}>
            {title}
          </Heading>
          <Text align="center" muted size={1}>
            Browse workshop stories in the navigator to the left.
          </Text>
        </Stack>
      )}

      {!frameReady && path !== '/' && <Spinner muted />}

      <Card
        as="iframe"
        hidden={!frameReady || path === '/'}
        ref={frameRef}
        shadow={1}
        src={initialFrameUrl}
        style={{
          transform: `scale(${zoom || 1})`,
          transformOrigin: '50% 50%',
          maxWidth: viewportW === 'auto' ? undefined : viewportW * (zoom || 1),
          maxHeight: viewportH === 'auto' ? undefined : viewportH * (zoom || 1),
          width: `${100 / zoom || 1}%`,
          height: `${100 / zoom || 1}%`,
        }}
      />
    </Card>
  )
})
