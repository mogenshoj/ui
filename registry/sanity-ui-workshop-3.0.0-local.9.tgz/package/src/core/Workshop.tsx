import {
  BoundaryElementProvider,
  CardProvider,
  Flex,
  PortalProvider,
  ToastProvider,
  useMediaIndex,
} from '@sanity/ui'
import {ThemeColorSchemeKey} from '@sanity/ui/theme'
import {memo, useCallback, useEffect, useMemo, useRef, useState} from 'react'

import {WorkshopConfig} from './config'
import {DEFAULT_VIEWPORT_VALUE, DEFAULT_ZOOM_VALUE} from './constants'
import {WorkshopInspector} from './inspector'
import {debounce} from './lib/debounce'
import {createPubsub} from './lib/pubsub'
import {WorkshopLocationStore} from './location'
import {WorkshopNavbar} from './navbar'
import {WorkshopNavigator} from './navigator'
import {RootClassNames} from './RootClassNames'
import {WorkshopLocation, WorkshopMsg, WorkshopQuery, WorkshopState} from './types'
import {WorkshopCanvas} from './WorkshopCanvas'
import {createWorkshopFrameController} from './WorkshopFrameController'
import {WorkshopProvider} from './WorkshopProvider'
import {workshopReducer} from './workshopReducer'

/** @public */
export interface WorkshopProps {
  config: WorkshopConfig
  locationStore: WorkshopLocationStore
  initialScheme: ThemeColorSchemeKey
}

function getStateFromLocation(
  loc: Omit<WorkshopLocation, 'type'>,
  schemeProp: ThemeColorSchemeKey,
  frameReady?: boolean,
): WorkshopState {
  const path = loc.path
  const query = loc.query ?? {}
  const {scheme, viewport, zoom, ...payload} = query

  return {
    context: 'main',
    frameReady: frameReady ?? false,
    path,
    payload,
    scheme: typeof scheme === 'string' ? (scheme as ThemeColorSchemeKey) : schemeProp,
    viewport: typeof viewport === 'string' ? viewport : 'auto',
    zoom: typeof zoom === 'string' ? Number(zoom) : 1,
  }
}

function getQueryFromState(state: WorkshopState): WorkshopQuery {
  const {payload, scheme, viewport, zoom} = state

  const query: WorkshopQuery = {scheme}

  if (viewport && viewport !== DEFAULT_VIEWPORT_VALUE) {
    query.viewport = viewport
  }

  if (zoom && zoom !== DEFAULT_ZOOM_VALUE) {
    query.zoom = zoom
  }

  for (const [key, val] of Object.entries(payload)) {
    if (['schema', 'viewport', 'zoom'].includes(key)) {
      // eslint-disable-next-line no-console
      console.warn(
        `Workshop: the payload cannot contain a property named "${key}" (protected name)`,
      )
    } else {
      query[key] = val
    }
  }

  return query
}

/** @public */
export const Workshop = memo(function Workshop(props: WorkshopProps): React.ReactNode {
  const {config, locationStore, initialScheme} = props
  const withNavbar = config.features?.navbar ?? true
  const channel = useMemo(() => createPubsub<WorkshopMsg>(), [])
  const frame = useMemo(() => createWorkshopFrameController(), [])
  const [boundaryElement, setBoundaryElement] = useState<HTMLDivElement | null>(null)
  const [portalElement, setPortalElement] = useState<HTMLDivElement | null>(null)
  const [{frameReady, path, payload, scheme, viewport, zoom}, setState] = useState<WorkshopState>(
    () => getStateFromLocation(locationStore.get(), initialScheme),
  )
  const mediaIndex = useMediaIndex()
  const [navigatorExpanded, setNavigatorExpanded] = useState(false)
  const [inspectorExpanded, setInspectorExpanded] = useState(false)
  const frameReadyRef = useRef(frameReady)

  const schemeRef = useRef(scheme)
  const pathRef = useRef(path)
  const viewportRef = useRef(viewport)
  const zoomRef = useRef(zoom)
  const payloadRef = useRef(JSON.stringify(payload))

  const broadcast = useCallback(
    (msg: WorkshopMsg) => {
      // Handle msg
      channel.publish(msg)

      // Pass message to frame
      frame.message.publish(msg)
    },
    [channel, frame],
  )

  const _pushLocation = useMemo(
    () => debounce((loc: Omit<WorkshopLocation, 'type'>) => locationStore.push(loc), 150),
    [locationStore],
  )

  const _replaceLocation = useMemo(
    () => debounce((loc: Omit<WorkshopLocation, 'type'>) => locationStore.replace(loc), 150),
    [locationStore],
  )

  const handleNavigatorToggle = useCallback(() => {
    setNavigatorExpanded((v) => !v)
    setInspectorExpanded(false)
  }, [])

  const handleInspectorToggle = useCallback(() => {
    setNavigatorExpanded(false)
    setInspectorExpanded((v) => !v)
  }, [])

  const mediaIndexRef = useRef(mediaIndex)

  useEffect(() => {
    const prevMediaIndex = mediaIndexRef.current

    if (prevMediaIndex < 2 && mediaIndex >= 2) {
      setNavigatorExpanded(false)
      setInspectorExpanded(false)
    }

    mediaIndexRef.current = mediaIndex
  }, [mediaIndex])

  useEffect(() => {
    setNavigatorExpanded(false)
  }, [path])

  // Cancel debounced functions
  useEffect(() => () => _pushLocation.cancel(), [_pushLocation])
  useEffect(() => () => _replaceLocation.cancel(), [_replaceLocation])

  // Subscribe to global message channel
  useEffect(
    () =>
      channel.subscribe((msg) => {
        setState((prevState) => {
          const nextState = workshopReducer(prevState, msg)

          if (
            pathRef.current !== nextState.path ||
            schemeRef.current !== nextState.scheme ||
            viewportRef.current !== nextState.viewport ||
            zoomRef.current !== nextState.zoom ||
            payloadRef.current !== JSON.stringify(nextState.payload)
          ) {
            const nextLocation = {
              path: nextState.path,
              query: getQueryFromState(nextState),
            }

            if (msg.type === 'workshop/setPath') {
              _pushLocation(nextLocation)
            } else {
              _replaceLocation(nextLocation)
            }
          }

          pathRef.current = nextState.path
          schemeRef.current = nextState.scheme
          viewportRef.current = nextState.viewport
          zoomRef.current = nextState.zoom
          payloadRef.current = JSON.stringify(nextState.payload)

          return nextState
        })
      }),
    [_pushLocation, _replaceLocation, channel, locationStore],
  )

  // Pipe messages from frame to channel
  useEffect(() => frame.message.subscribe(channel.publish), [channel, frame])

  useEffect(() => {
    frameReadyRef.current = frameReady
  }, [frameReady])

  if (!config.scopes) {
    return <>No scopes</>
  }

  return (
    <CardProvider scheme={scheme} tone="default">
      <RootClassNames />

      <WorkshopProvider
        config={config}
        broadcast={broadcast}
        channel={channel}
        frameReady={frameReady}
        origin="main"
        path={path}
        payload={payload}
        scheme={scheme}
        viewport={viewport}
        zoom={zoom}
      >
        <ToastProvider>
          <BoundaryElementProvider element={boundaryElement}>
            <PortalProvider element={portalElement}>
              <Flex
                data-boundary=""
                direction="column"
                height="fill"
                ref={setBoundaryElement}
                style={{minWidth: 320}}
              >
                {withNavbar && (
                  <WorkshopNavbar
                    inspectorExpanded={inspectorExpanded}
                    navigatorExpanded={navigatorExpanded}
                    onInspectorToggle={handleInspectorToggle}
                    onNavigatorToggle={handleNavigatorToggle}
                  />
                )}

                <Flex flex={1}>
                  <WorkshopNavigator
                    collections={config.collections}
                    expanded={navigatorExpanded}
                  />
                  <WorkshopCanvas
                    frameRef={frame.setElement}
                    hidden={navigatorExpanded || inspectorExpanded}
                  />
                  <WorkshopInspector expanded={inspectorExpanded} />
                </Flex>

                <div data-portal="" ref={setPortalElement} />
              </Flex>
            </PortalProvider>
          </BoundaryElementProvider>
        </ToastProvider>
      </WorkshopProvider>
    </CardProvider>
  )
})
