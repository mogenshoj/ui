import {useEffect} from 'react'

import {useProps} from '../useProps'

/** @public */
export function useNumber(name: string, defaultValue: number, groupName?: string): number
/** @public */
export function useNumber(name: string, defaultValue?: number): number | undefined
/** @public */
export function useNumber(
  name: string,
  defaultValue?: number,
  groupName = 'Props',
): number | undefined {
  const {registerProp, unregisterProp, value} = useProps()

  useEffect(() => {
    registerProp({
      type: 'number',
      groupName,
      name,
      defaultValue,
    })

    return () => unregisterProp(name)
  }, [defaultValue, groupName, name, registerProp, unregisterProp])

  return value[name] === undefined ? defaultValue : (value[name] as number)
}
