import {useCard} from '@sanity/ui'
import {card, defaultTheme} from '@sanity/ui/css'
import {type ReactNode, useEffect} from 'react'

export function RootClassNames(): ReactNode {
  const {scheme, tone} = useCard() ?? {}

  useEffect(() => {
    const updateRootClassNames = () => {
      document.documentElement.className = card({className: defaultTheme, scheme, tone}) ?? ''
    }

    if (document.startViewTransition) {
      document.startViewTransition(() => {
        updateRootClassNames()
      })
      return
    }

    updateRootClassNames()
  }, [scheme, tone])

  return null
}
